simvis_attributes =
{
	selection_child			= 1,
	selection_ground		= 1,
}

