g_AllRaces = { "space_marine_race", "chaos_marine_race", "eldar_race", "ork_race", "guard_race", "necron_race", "dark_eldar_race", "sisters_race" }
g_AllPaints = { "default_0", "default_1", "default_2", "default_3", "default_4", "default_5", "default_6", "default_7" }
g_RacePriority = { 0, 0, 0, 0, 0, 0, 0, 0 }