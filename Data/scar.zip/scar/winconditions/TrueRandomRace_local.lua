Localization = 
{
exclusive = false,
victory_condition = false,
always_on = false,
title = "True Random Race",
win_message = "",
lose_message = "",
description = "Chooses a random race for both players, does not allow mirrors."
}
