Localization = 
{
exclusive = false,
victory_condition = false,
always_on = true,
title = "UBM",
win_message = "",
lose_message = "",
description = "Core code for UBM Mod."
}
