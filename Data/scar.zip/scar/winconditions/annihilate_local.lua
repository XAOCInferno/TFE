Localization = 
{
	exclusive				= false,
	victory_condition	= true,
	always_on			= false,
	title						= "$60000",
	win_message		= "$60100",
	lose_message		= "$60200",
	description			= "$60300"
}
