Localization = 
{
exclusive = false,
victory_condition = false,
always_on = false,
title = "Cosmetic: Race Theme Music",
win_message = "",
lose_message = "",
description = "Plays Your Faciton Motif At Game Start."
}
